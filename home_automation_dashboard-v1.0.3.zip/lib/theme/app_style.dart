import 'package:flutter/material.dart';
import 'package:home_automation_dashboard/core/app_export.dart';

class AppStyle {}
