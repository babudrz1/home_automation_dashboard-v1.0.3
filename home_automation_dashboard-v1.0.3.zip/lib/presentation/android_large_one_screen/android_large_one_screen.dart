import 'package:flutter/material.dart';
import 'package:home_automation_dashboard/core/app_export.dart';

class AndroidLargeOneScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: getVerticalSize(
            773,
          ),
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.center,
                child: SingleChildScrollView(
                  child: Container(
                    height: getVerticalSize(
                      773,
                    ),
                    width: double.maxFinite,
                  ),
                ),
              ),
              CustomImageView(
                imagePath: ImageConstant.imgImageprocessin,
                height: getVerticalSize(
                  749,
                ),
                width: getHorizontalSize(
                  360,
                ),
                radius: BorderRadius.circular(
                  getHorizontalSize(
                    102,
                  ),
                ),
                alignment: Alignment.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
