import 'package:flutter/material.dart';
import 'package:home_automation_dashboard/presentation/android_large_one_screen/android_large_one_screen.dart';

class AppRoutes {
  static const String androidLargeOneScreen = '/android_large_one_screen';

  static Map<String, WidgetBuilder> routes = {
    androidLargeOneScreen: (context) => AndroidLargeOneScreen()
  };
}
