class ImageConstant {
  static String imgImageprocessin = 'assets/images/img_imageprocessin.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
