package com.homeautomationdashboard.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
